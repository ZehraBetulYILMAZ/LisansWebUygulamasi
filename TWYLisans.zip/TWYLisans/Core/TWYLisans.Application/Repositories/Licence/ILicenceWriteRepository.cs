﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TWYLisans.Domain.Entities;

namespace TWYLisans.Application.Repositories
{
    public interface ILicenceWriteRepository:IWriteRepository<Licence>
    {
        bool RemoveLicence(int id);
        bool UpdateLicence(Licence entity);
    }
}
