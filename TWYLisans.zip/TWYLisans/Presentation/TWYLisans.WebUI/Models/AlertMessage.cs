﻿namespace TWYLisans.WebUI.Models
{
    public class AlertMessage
    {
        public string message { get; set; }
        public string alertType { get; set; }
    }
}
